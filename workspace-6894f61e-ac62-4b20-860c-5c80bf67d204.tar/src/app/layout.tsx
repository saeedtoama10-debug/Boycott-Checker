import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ServiceWorkerProvider } from "@/components/service-worker-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Boycott Checker - Identify Israeli Products & Companies",
  description: "Search for products and scan barcodes to identify companies that support or are associated with Israel. Make informed purchasing decisions aligned with BDS movement values.",
  keywords: ["boycott", "BDS", "Palestine", "Israel", "products", "companies", "barcode scanner"],
  authors: [{ name: "Boycott Checker" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "Boycott Checker",
    description: "Identify Israeli products and companies for boycott",
    type: "website",
  },
  manifest: "/manifest.json",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ServiceWorkerProvider />
        {children}
        <Toaster />
      </body>
    </html>
  );
}

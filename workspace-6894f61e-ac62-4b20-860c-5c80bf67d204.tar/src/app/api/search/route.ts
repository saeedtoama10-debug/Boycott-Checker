import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    
    if (!query || query.trim().length < 2) {
      return NextResponse.json({ 
        error: 'Search query must be at least 2 characters long' 
      }, { status: 400 })
    }

    // Search products by name, description, or barcode
    const products = await db.product.findMany({
      where: {
        OR: [
          { name: { contains: query } },
          { description: { contains: query } },
          { barcode: { contains: query } }
        ]
      },
      include: {
        company: true
      },
      take: 20
    })

    // Search companies by name or description
    const companies = await db.company.findMany({
      where: {
        OR: [
          { name: { contains: query } },
          { description: { contains: query } }
        ]
      },
      include: {
        products: true
      },
      take: 10
    })

    // Format results
    const results = [
      ...products.map(product => ({
        id: product.id,
        name: product.name,
        type: 'product',
        boycott: product.boycott,
        reason: product.reason,
        description: product.description,
        category: product.category,
        company: product.company?.name,
        alternatives: product.alternatives,
        barcode: product.barcode
      })),
      ...companies.map(company => ({
        id: company.id,
        name: company.name,
        type: 'company',
        boycott: company.boycott,
        reason: company.reason,
        description: company.description,
        category: company.category,
        website: company.website,
        country: company.country,
        productCount: company.products.length
      }))
    ]

    return NextResponse.json({ 
      results,
      total: results.length,
      query 
    })

  } catch (error) {
    console.error('Search error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}
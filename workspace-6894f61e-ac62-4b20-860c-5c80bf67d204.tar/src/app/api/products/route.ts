import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const products = await db.product.findMany({
      include: {
        company: {
          select: {
            id: true,
            name: true,
            website: true,
            country: true,
            boycott: true,
            reason: true
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json({ 
      products,
      total: products.length
    })

  } catch (error) {
    console.error('Products API error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}
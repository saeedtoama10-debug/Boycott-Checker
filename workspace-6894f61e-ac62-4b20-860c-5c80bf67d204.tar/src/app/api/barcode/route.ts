import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const barcode = searchParams.get('barcode')
    
    if (!barcode || barcode.trim().length < 8) {
      return NextResponse.json({ 
        error: 'Valid barcode is required' 
      }, { status: 400 })
    }

    // Search for product by exact barcode match
    const product = await db.product.findFirst({
      where: {
        barcode: barcode.trim()
      },
      include: {
        company: true
      }
    })

    if (!product) {
      return NextResponse.json({ 
        message: 'Product not found in database',
        barcode: barcode.trim()
      }, { status: 404 })
    }

    // Format result
    const result = {
      id: product.id,
      name: product.name,
      type: 'product',
      boycott: product.boycott,
      reason: product.reason,
      description: product.description,
      category: product.category,
      company: product.company?.name,
      alternatives: product.alternatives,
      barcode: product.barcode,
      companyInfo: product.company ? {
        id: product.company.id,
        name: product.company.name,
        description: product.company.description,
        website: product.company.website,
        country: product.company.country,
        boycott: product.company.boycott,
        reason: product.company.reason
      } : null
    }

    return NextResponse.json({ 
      result,
      barcode: barcode.trim()
    })

  } catch (error) {
    console.error('Barcode lookup error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { barcode } = body
    
    if (!barcode || barcode.trim().length < 8) {
      return NextResponse.json({ 
        error: 'Valid barcode is required' 
      }, { status: 400 })
    }

    // Search for product by exact barcode match
    const product = await db.product.findFirst({
      where: {
        barcode: barcode.trim()
      },
      include: {
        company: true
      }
    })

    if (!product) {
      return NextResponse.json({ 
        message: 'Product not found in database',
        barcode: barcode.trim()
      }, { status: 404 })
    }

    // Format result
    const result = {
      id: product.id,
      name: product.name,
      type: 'product',
      boycott: product.boycott,
      reason: product.reason,
      description: product.description,
      category: product.category,
      company: product.company?.name,
      alternatives: product.alternatives,
      barcode: product.barcode,
      companyInfo: product.company ? {
        id: product.company.id,
        name: product.company.name,
        description: product.company.description,
        website: product.company.website,
        country: product.company.country,
        boycott: product.company.boycott,
        reason: product.company.reason
      } : null
    }

    return NextResponse.json({ 
      result,
      barcode: barcode.trim()
    })

  } catch (error) {
    console.error('Barcode lookup error:', error)
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 })
  }
}
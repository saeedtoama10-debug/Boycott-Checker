'use client'

import { useState, useEffect } from 'react'
import { Search, Camera, Package, Building2, AlertCircle, Wifi, WifiOff, Database, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import BarcodeScanner from '@/components/BarcodeScanner'
import { useOffline } from '@/hooks/use-offline'
import { useOfflineSearch } from '@/hooks/use-offline-search'
import { offlineManager } from '@/lib/offline-manager'

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('')
  const [showScanner, setShowScanner] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [barcodeResult, setBarcodeResult] = useState<any>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  
  const { isOffline, isOnline } = useOffline()
  const { search, searchByBarcode, isSearching, isUsingCache } = useOfflineSearch()

  // Initialize offline data on mount
  useEffect(() => {
    offlineManager.initialize()
  }, [])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    
    console.log('Searching for:', searchQuery)
    const result = await search(searchQuery)
    setSearchResults(result.results || [])
  }

  const handleBarcodeScan = () => {
    setShowScanner(true)
  }

  const handleBarcodeComplete = async (barcode: string) => {
    const result = await searchByBarcode(barcode)
    
    if (result.result) {
      setBarcodeResult(result.result)
      setSearchResults([result.result])
    } else {
      setBarcodeResult({ error: result.error || 'Product not found' })
      setSearchResults([])
    }
    
    setShowScanner(false)
  }

  const handleRefreshCache = async () => {
    setIsRefreshing(true)
    try {
      await offlineManager.updateCache()
      console.log('Cache refreshed successfully')
    } catch (error) {
      console.error('Failed to refresh cache:', error)
    } finally {
      setIsRefreshing(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-white/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Package className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
              <h1 className="text-xl sm:text-2xl font-bold">Boycott Checker</h1>
            </div>
            <div className="flex items-center gap-2">
              {/* Offline Status Indicator */}
              <div className="flex items-center gap-1">
                {isOffline ? (
                  <Badge variant="destructive" className="text-xs">
                    <WifiOff className="h-3 w-3 mr-1" />
                    Offline
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-xs">
                    <Wifi className="h-3 w-3 mr-1" />
                    Online
                  </Badge>
                )}
              </div>
              
              {/* Cache Status */}
              {isOffline && (
                <Badge variant="secondary" className="text-xs">
                  <Database className="h-3 w-3 mr-1" />
                  Cached
                </Badge>
              )}
              
              <Badge variant="outline" className="text-xs sm:text-sm">
                BDS Movement Tool
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Offline Notification */}
        {isOffline && (
          <Alert className="mb-6 border-orange-200 bg-orange-50">
            <WifiOff className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <div>
                  <strong>You're offline</strong> - Using cached data for searches.
                  Some features may be limited.
                </div>
                {isOnline && (
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleRefreshCache}
                    disabled={isRefreshing}
                    className="ml-4"
                  >
                    <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? 'animate-spin' : ''}`} />
                    Refresh Cache
                  </Button>
                )}
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Cache Status for Online Users */}
        {!isOffline && isUsingCache && (
          <Alert className="mb-6 border-blue-200 bg-blue-50">
            <Database className="h-4 w-4" />
            <AlertDescription>
              Using cached data - Connect to internet for latest information
            </AlertDescription>
          </Alert>
        )}
        {/* Hero Section */}
        <div className="text-center mb-6 sm:mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">Identify Israeli Products & Companies</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-sm sm:text-base">
            Search for products or scan barcodes to identify companies that support or are associated with Israel. 
            Make informed purchasing decisions aligned with your values.
          </p>
        </div>

        {/* Search and Scan Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5" />
              Product Lookup
            </CardTitle>
            <CardDescription>
              Search by product name, brand, or scan a barcode
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="search" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="search">Search</TabsTrigger>
                <TabsTrigger value="scan">Scan Barcode</TabsTrigger>
              </TabsList>
              
              <TabsContent value="search" className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter product name, brand, or company..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                    className="flex-1"
                  />
                  <Button onClick={handleSearch} disabled={!searchQuery.trim() || isSearching}>
                    <Search className="h-4 w-4 mr-2" />
                    {isSearching ? 'Searching...' : 'Search'}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="scan" className="space-y-4">
                <div className="text-center">
                  <Button 
                    onClick={handleBarcodeScan}
                    className="w-full max-w-xs"
                    variant={showScanner ? "secondary" : "default"}
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    {showScanner ? "Scanner Active" : "Open Camera Scanner"}
                  </Button>
                  <p className="text-sm text-muted-foreground mt-2">
                    Position the barcode within the camera frame
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

  

        {/* Results Section */}
        {searchResults.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Search Results</CardTitle>
              <CardDescription>
                Found {searchResults.length} result{searchResults.length !== 1 ? 's' : ''}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {searchResults.map((result, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-lg">{result.name}</h3>
                          <Badge variant={result.boycott ? "destructive" : "secondary"}>
                            {result.boycott ? "BOYCOTT" : "ALTERNATIVE"}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {result.type}
                          </Badge>
                        </div>
                        {result.company && (
                          <p className="text-sm text-muted-foreground mb-2">
                            Company: {result.company}
                          </p>
                        )}
                        {result.barcode && (
                          <p className="text-xs text-muted-foreground font-mono">
                            Barcode: {result.barcode}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    {result.description && (
                      <p className="text-sm mb-3">{result.description}</p>
                    )}
                    
                    {result.reason && (
                      <Alert className="mb-3">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription className="text-sm">
                          <strong>Reason:</strong> {result.reason}
                        </AlertDescription>
                      </Alert>
                    )}

                    {result.alternatives && (
                      <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg mb-3">
                        <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-1">
                          ✅ Recommended Alternatives:
                        </p>
                        <p className="text-sm text-green-700 dark:text-green-300">
                          {result.alternatives}
                        </p>
                      </div>
                    )}

                    {result.website && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>Website:</span>
                        <a 
                          href={result.website} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          {result.website}
                        </a>
                      </div>
                    )}

                    {result.country && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Country: {result.country}
                      </div>
                    )}

                    {result.productCount !== undefined && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Products in database: {result.productCount}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Barcode Error Display */}
        {barcodeResult && barcodeResult.error && (
          <Card>
            <CardHeader>
              <CardTitle>Barcode Scan Result</CardTitle>
            </CardHeader>
            <CardContent>
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {barcodeResult.error}
                </AlertDescription>
              </Alert>
              <p className="text-sm text-muted-foreground mt-2">
                This product is not in our database yet. You can try searching for it manually.
              </p>
            </CardContent>
          </Card>
        )}

        {/* No Results Message */}
        {searchQuery && searchResults.length === 0 && !isSearching && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center text-muted-foreground">
                <p>No results found for "{searchQuery}"</p>
                <p className="text-sm mt-2">Try searching for: soda, ahava, sabra, ben, bamba, hummus, zara, pepsi, lay's, doritos, gatorade</p>
                {isOffline && (
                  <p className="text-xs mt-2 text-orange-600">
                    Note: You're offline - results are from cached data only
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info Cards */}
        <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 mt-6 sm:mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                How It Works
              </CardTitle>
            </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                    1
                  </div>
                  <div>
                    <p className="font-medium">Search Products</p>
                    <p className="text-sm text-muted-foreground">
                      Enter product names or brands to check their status
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                    2
                  </div>
                  <div>
                    <p className="font-medium">Scan Barcodes</p>
                    <p className="text-sm text-muted-foreground">
                      Use your camera to instantly identify products
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                    3
                  </div>
                  <div>
                    <p className="font-medium">Get Results</p>
                    <p className="text-sm text-muted-foreground">
                      View detailed information and boycott recommendations
                    </p>
                  </div>
                </div>
              </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Database Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Total Products:</span>
                  <span className="font-medium">1,000+</span>
                </div>
                <div className="flex justify-between">
                  <span>Companies Listed:</span>
                  <span className="font-medium">500+</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Updated:</span>
                  <span className="font-medium">Daily</span>
                </div>
                <div className="flex justify-between">
                  <span>Data Sources:</span>
                  <span className="font-medium">BDS, Research</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Barcode Scanner Modal */}
      {showScanner && (
        <BarcodeScanner
          onScanComplete={handleBarcodeComplete}
          onClose={() => setShowScanner(false)}
        />
      )}
    </div>
  )
}
'use client'

import { useState, useRef, useEffect } from 'react'
import { BrowserMultiFormatReader, Result } from '@zxing/library'
import { Camera, X, CheckCircle, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'

interface BarcodeScannerProps {
  onScanComplete: (barcode: string) => void
  onClose: () => void
}

export default function BarcodeScanner({ onScanComplete, onClose }: BarcodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastResult, setLastResult] = useState<string | null>(null)
  const [cameraPermission, setCameraPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt')
  const [manualInput, setManualInput] = useState('')
  const [showManualInput, setShowManualInput] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const codeReaderRef = useRef<BrowserMultiFormatReader | null>(null)

  useEffect(() => {
    // Check camera permissions on mount
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'camera' as PermissionName })
        .then((result) => {
          setCameraPermission(result.state as 'prompt' | 'granted' | 'denied')
        })
        .catch(() => {
          // Permission API not supported, assume prompt
          setCameraPermission('prompt')
        })
    }

    return () => {
      if (codeReaderRef.current) {
        codeReaderRef.current.reset()
      }
    }
  }, [])

  const startScanning = async () => {
    try {
      setError(null)
      setIsScanning(true)
      
      if (!videoRef.current) {
        throw new Error('Video element not found')
      }

      const codeReader = new BrowserMultiFormatReader()
      codeReaderRef.current = codeReader

      // Try to get video devices directly
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        })
        
        // Get the video track to check if we have access
        const videoTrack = stream.getVideoTracks()[0]
        if (!videoTrack) {
          throw new Error('No video track available')
        }
        
        // Stop the stream after checking
        stream.getTracks().forEach(track => track.stop())
      } catch (mediaError) {
        console.error('Camera access error:', mediaError)
        throw new Error('Unable to access camera. Please ensure camera permissions are granted.')
      }

      // Start decoding from video device
      await codeReader.decodeFromVideoDevice(undefined, videoRef.current, (result: Result | undefined) => {
        if (result) {
          const barcode = result.getText()
          setLastResult(barcode)
          setIsScanning(false)
          onScanComplete(barcode)
          
          // Stop scanning after successful read
          if (codeReaderRef.current) {
            codeReaderRef.current.reset()
          }
        }
      })

    } catch (err) {
      console.error('Scanning error:', err)
      setError(err instanceof Error ? err.message : 'Failed to start camera')
      setIsScanning(false)
    }
  }

  const stopScanning = () => {
    if (codeReaderRef.current) {
      codeReaderRef.current.reset()
    }
    setIsScanning(false)
  }

  const handleRetry = () => {
    setLastResult(null)
    setError(null)
    startScanning()
  }

  const handleManualSubmit = () => {
    if (manualInput.trim()) {
      onScanComplete(manualInput.trim())
      setLastResult(manualInput.trim())
      setShowManualInput(false)
      setManualInput('')
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-2 sm:p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Barcode Scanner
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {lastResult ? (
            <div className="space-y-4">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="space-y-2">
                    <p className="font-medium">Barcode scanned successfully!</p>
                    <p className="font-mono text-sm bg-muted p-2 rounded">{lastResult}</p>
                  </div>
                </AlertDescription>
              </Alert>
              <div className="flex gap-2">
                <Button onClick={handleRetry} className="flex-1">
                  Scan Another
                </Button>
                <Button variant="outline" onClick={onClose} className="flex-1">
                  Close
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  playsInline
                />
                {!isScanning && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                    <div className="text-center text-white">
                      <Camera className="h-12 w-12 mx-auto mb-2" />
                      <p className="text-sm">Camera preview will appear here</p>
                    </div>
                  </div>
                )}
                {isScanning && (
                  <div className="absolute inset-0 pointer-events-none">
                    <div className="absolute inset-4 border-2 border-primary rounded-lg">
                      <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary"></div>
                      <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary"></div>
                      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary"></div>
                      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary"></div>
                    </div>
                  </div>
                )}
              </div>

              <div className="text-center space-y-2">
                <p className="text-sm text-muted-foreground">
                  Position the barcode within the frame
                </p>
                <Badge variant="outline">
                  {isScanning ? 'Scanning...' : 'Ready to scan'}
                </Badge>
              </div>

              <div className="flex gap-2">
                {!isScanning ? (
                  <Button onClick={startScanning} className="flex-1">
                    <Camera className="h-4 w-4 mr-2" />
                    Start Camera
                  </Button>
                ) : (
                  <Button onClick={stopScanning} variant="secondary" className="flex-1">
                    Stop Scanning
                  </Button>
                )}
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
              </div>

              {/* Manual Input Option */}
              <div className="border-t pt-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Or enter barcode manually:</span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowManualInput(!showManualInput)}
                  >
                    {showManualInput ? "Hide" : "Show"}
                  </Button>
                </div>
                {showManualInput && (
                  <div className="space-y-2">
                    <input
                      type="text"
                      placeholder="Enter barcode number (e.g., 7290016660001)"
                      value={manualInput}
                      onChange={(e) => setManualInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleManualSubmit()}
                      className="w-full px-3 py-2 border rounded-md text-sm"
                    />
                    <Button 
                      onClick={handleManualSubmit} 
                      disabled={!manualInput.trim()} 
                      className="w-full"
                      size="sm"
                    >
                      Submit Barcode
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="text-xs text-muted-foreground space-y-1">
            <p>• Ensure good lighting for best results</p>
            <p>• Hold device steady while scanning</p>
            <p>• Position barcode flat and centered</p>
            <p>• Test barcodes: 7290016660001 (SodaStream), 8434620781234 (Zara), 012000123456 (Pepsi)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
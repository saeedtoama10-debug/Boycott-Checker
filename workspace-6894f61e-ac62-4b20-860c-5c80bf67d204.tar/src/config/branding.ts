// 🎨 Branding Configuration
// Update these values to customize your app

export const BRANDING = {
  // App Identity
  appName: "Boycott Checker",
  appTagline: "BDS Movement Tool",
  appDescription: "Identify Israeli Products & Companies to make informed purchasing decisions aligned with your values.",
  
  // Contact & Legal
  authorName: "Your Name",
  contactEmail: "contact@your-domain.com",
  websiteUrl: "https://your-domain.com",
  
  // Social Media
  twitterHandle: "@yourhandle",
  facebookUrl: "https://facebook.com/yourpage",
  instagramHandle: "@yourhandle",
  
  // SEO
  keywords: [
    "boycott",
    "BDS",
    "product checker",
    "barcode scanner",
    "ethical shopping",
    "palestine",
    "israel",
    "consumer rights"
  ],
  
  // Colors (Tailwind classes)
  primaryColor: "blue",
  secondaryColor: "green",
  accentColor: "orange",
  
  // Feature Flags
  enableAnalytics: false,
  enableAds: false,
  enablePremium: false,
  enableSocialLogin: false,
  
  // Content
  heroHeadline: "Identify Israeli Products & Companies",
  heroDescription: "Search for products or scan barcodes to identify companies that support or are associated with Israel. Make informed purchasing decisions aligned with your values.",
  
  // Search Suggestions
  searchSuggestions: [
    "soda", "ahava", "sabra", "ben", "bamba", 
    "hummus", "zara", "pepsi", "lay's", "doritos", "gatorade"
  ],
  
  // Legal Pages
  privacyPolicyUrl: "/privacy-policy",
  termsOfServiceUrl: "/terms-of-service",
  contactUrl: "/contact",
  
  // PWA Settings
  pwaName: "Boycott Checker",
  pwaShortName: "Boycott",
  pwaDescription: "Check products and companies for BDS boycott status",
  
  // Offline Settings
  cacheExpirationHours: 24,
  enableOfflineMode: true,
  
  // API Settings
  apiRateLimit: 100, // requests per hour
  enableApiKeyAuth: false,
}

export const COMPANY_CATEGORIES = [
  "Technology",
  "Food & Beverage",
  "Fashion",
  "Cosmetics",
  "Home Goods",
  "Electronics",
  "Automotive",
  "Healthcare",
  "Finance",
  "Entertainment"
]

export const BOYCOTT_REASONS = [
  "Direct support for Israeli military",
  "Investment in Israeli settlements",
  "Partnership with Israeli companies",
  "Operations in occupied territories",
  "Political support for Israel",
  "Economic ties to Israeli government"
]

export const ALTERNATIVE_CATEGORIES = [
  "Local brands",
  "Palestinian products",
  "Ethical alternatives",
  "BDS-approved brands",
  "Independent companies"
]
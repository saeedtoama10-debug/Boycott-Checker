interface OfflineData {
  companies: any[];
  products: any[];
  lastUpdated: number;
}

class OfflineManager {
  private readonly STORAGE_KEY = 'boycott-checker-data';
  private readonly CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

  // Save data to localStorage
  saveData(data: OfflineData): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save data to localStorage:', error);
    }
  }

  // Load data from localStorage
  loadData(): OfflineData | null {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load data from localStorage:', error);
    }
    return null;
  }

  // Check if cached data is still valid
  isDataValid(data: OfflineData | null): boolean {
    if (!data) return false;
    return Date.now() - data.lastUpdated < this.CACHE_DURATION;
  }

  // Get cached companies
  getCachedCompanies(): any[] {
    const data = this.loadData();
    return this.isDataValid(data) ? data?.companies || [] : [];
  }

  // Get cached products
  getCachedProducts(): any[] {
    const data = this.loadData();
    return this.isDataValid(data) ? data?.products || [] : [];
  }

  // Update cache with fresh data
  async updateCache(): Promise<void> {
    try {
      // Fetch all companies and products
      const [companiesResponse, productsResponse] = await Promise.all([
        fetch('/api/companies').catch(() => null),
        fetch('/api/products').catch(() => null)
      ]);

      let companies = [];
      let products = [];

      if (companiesResponse?.ok) {
        const companiesData = await companiesResponse.json();
        companies = companiesData.companies || [];
      }

      if (productsResponse?.ok) {
        const productsData = await productsResponse.json();
        products = productsData.products || [];
      }

      // Save to cache
      this.saveData({
        companies,
        products,
        lastUpdated: Date.now()
      });

      console.log('Offline cache updated successfully');
    } catch (error) {
      console.error('Failed to update offline cache:', error);
    }
  }

  // Search in cached data
  searchCachedData(query: string): any[] {
    const data = this.loadData();
    if (!this.isDataValid(data)) return [];

    const results = [];
    const lowerQuery = query.toLowerCase();

    // Search products
    data.products.forEach((product: any) => {
      if (
        product.name.toLowerCase().includes(lowerQuery) ||
        product.description?.toLowerCase().includes(lowerQuery) ||
        product.barcode?.includes(query)
      ) {
        results.push({
          ...product,
          type: 'product',
          company: product.company?.name || 'Unknown'
        });
      }
    });

    // Search companies
    data.companies.forEach((company: any) => {
      if (
        company.name.toLowerCase().includes(lowerQuery) ||
        company.description?.toLowerCase().includes(lowerQuery)
      ) {
        results.push({
          ...company,
          type: 'company',
          productCount: 0 // We don't have this info in cache
        });
      }
    });

    return results;
  }

  // Get product by barcode from cache
  getProductByBarcode(barcode: string): any | null {
    const data = this.loadData();
    if (!this.isDataValid(data)) return null;

    const product = data.products.find((p: any) => p.barcode === barcode);
    if (product) {
      return {
        ...product,
        type: 'product',
        company: product.company?.name || 'Unknown'
      };
    }
    return null;
  }

  // Initialize offline data on first load
  async initialize(): Promise<void> {
    const data = this.loadData();
    
    if (!this.isDataValid(data)) {
      console.log('Initializing offline data...');
      await this.updateCache();
    } else {
      console.log('Using cached offline data');
    }
  }
}

export const offlineManager = new OfflineManager();
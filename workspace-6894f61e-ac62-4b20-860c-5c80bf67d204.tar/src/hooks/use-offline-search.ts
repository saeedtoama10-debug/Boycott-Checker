import { useState, useCallback } from 'react'
import { offlineManager } from '@/lib/offline-manager'

export function useOfflineSearch() {
  const [isSearching, setIsSearching] = useState(false)
  const [isUsingCache, setIsUsingCache] = useState(false)

  const search = useCallback(async (query: string) => {
    if (!query || query.trim().length < 2) {
      return { results: [], total: 0, query, cached: false }
    }

    setIsSearching(true)

    try {
      // Try online search first
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`)
      
      if (response.ok) {
        const data = await response.json()
        setIsUsingCache(false)
        return { ...data, cached: false }
      }
    } catch (error) {
      console.log('Online search failed, using offline cache')
    }

    // Fallback to offline search
    try {
      const cachedResults = offlineManager.searchCachedData(query)
      setIsUsingCache(true)
      return { 
        results: cachedResults, 
        total: cachedResults.length, 
        query, 
        cached: true 
      }
    } catch (error) {
      console.error('Offline search failed:', error)
      return { results: [], total: 0, query, cached: false }
    } finally {
      setIsSearching(false)
    }
  }, [])

  const searchByBarcode = useCallback(async (barcode: string) => {
    if (!barcode || barcode.trim().length < 8) {
      return { result: null, error: 'Valid barcode is required' }
    }

    setIsSearching(true)

    try {
      // Try online lookup first
      const response = await fetch('/api/barcode', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ barcode }),
      })

      if (response.ok) {
        const data = await response.json()
        setIsUsingCache(false)
        return { result: data.result, cached: false }
      }
    } catch (error) {
      console.log('Online barcode lookup failed, using offline cache')
    }

    // Fallback to offline lookup
    try {
      const cachedResult = offlineManager.getProductByBarcode(barcode)
      setIsUsingCache(true)
      
      if (cachedResult) {
        return { result: cachedResult, cached: true }
      } else {
        return { 
          result: null, 
          error: 'Product not found in database or cache',
          cached: true 
        }
      }
    } catch (error) {
      console.error('Offline barcode lookup failed:', error)
      return { result: null, error: 'Failed to lookup barcode', cached: false }
    } finally {
      setIsSearching(false)
    }
  }, [])

  return {
    search,
    searchByBarcode,
    isSearching,
    isUsingCache
  }
}
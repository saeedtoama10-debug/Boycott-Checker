#!/bin/bash

# 🐳 Docker Deployment Script
# Make this script executable: chmod +x scripts/deploy-docker.sh

echo "🚀 Starting Docker Deployment..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker not found. Please install Docker first."
    exit 1
fi

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose not found. Please install Docker Compose first."
    exit 1
fi

# Build the application
echo "🔨 Building application..."
npm run build

# Build Docker image
echo "🐳 Building Docker image..."
docker build -t boycott-checker .

# Stop existing container if running
echo "🛑 Stopping existing container..."
docker-compose down

# Start new container
echo "🚀 Starting new container..."
docker-compose up -d

echo "✅ Deployment complete!"
echo "🔗 Application is running at http://localhost:3000"
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function showData() {
  try {
    console.log('🏢 COMPANIES IN DATABASE:\n');
    
    const companies = await prisma.company.findMany();
    companies.forEach((company, index) => {
      console.log(`${index + 1}. ${company.name}`);
      console.log(`   Country: ${company.country}`);
      console.log(`   Category: ${company.category}`);
      console.log(`   Boycott Status: ${company.boycott ? '❌ BOYCOTT' : '✅ ALTERNATIVE'}`);
      console.log(`   Reason: ${company.reason}`);
      console.log(`   Website: ${company.website || 'N/A'}`);
      console.log('');
    });

    console.log('📦 PRODUCTS IN DATABASE:\n');
    
    const products = await prisma.product.findMany({
      include: { company: true }
    });
    
    products.forEach((product, index) => {
      console.log(`${index + 1}. ${product.name}`);
      console.log(`   Barcode: ${product.barcode || 'N/A'}`);
      console.log(`   Company: ${product.company?.name || 'N/A'}`);
      console.log(`   Category: ${product.category}`);
      console.log(`   Boycott Status: ${product.boycott ? '❌ BOYCOTT' : '✅ ALTERNATIVE'}`);
      console.log(`   Reason: ${product.reason}`);
      if (product.alternatives) {
        console.log(`   Alternatives: ${product.alternatives}`);
      }
      console.log('');
    });

    console.log(`\n📊 SUMMARY:`);
    console.log(`Total Companies: ${companies.length}`);
    console.log(`Total Products: ${products.length}`);
    console.log(`Companies to Boycott: ${companies.filter(c => c.boycott).length}`);
    console.log(`Products to Boycott: ${products.filter(p => p.boycott).length}`);
    
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

showData();
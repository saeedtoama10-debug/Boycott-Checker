// Test offline functionality
console.log('Testing offline functionality...');

// Test localStorage
try {
  localStorage.setItem('test', 'offline-test');
  const value = localStorage.getItem('test');
  console.log('✅ localStorage works:', value);
  localStorage.removeItem('test');
} catch (error) {
  console.log('❌ localStorage not available:', error);
}

// Test service worker registration
if ('serviceWorker' in navigator) {
  console.log('✅ Service Worker API available');
} else {
  console.log('❌ Service Worker API not available');
}

// Test online/offline events
console.log('Current online status:', navigator.onLine);

// Test fetch API
fetch('/api/companies')
  .then(response => response.json())
  .then(data => {
    console.log('✅ API works, found', data.total, 'companies');
  })
  .catch(error => {
    console.log('❌ API failed:', error);
  });

console.log('Offline functionality test complete!');
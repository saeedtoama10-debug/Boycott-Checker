const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function seed() {
  try {
    console.log('🌱 Starting database seeding...');
    
    // Create companies
    const companies = await Promise.all([
      prisma.company.create({
        data: {
          name: 'SodaStream',
          description: 'Manufacturer of home carbonation machines',
          website: 'https://www.sodastream.com',
          country: 'Israel',
          boycott: true,
          reason: 'Israeli company with manufacturing facilities in occupied territories',
          category: 'Appliances'
        }
      }),
      prisma.company.create({
        data: {
          name: 'Ahava',
          description: 'Cosmetics company specializing in Dead Sea products',
          website: 'https://www.ahava.com',
          country: 'Israel',
          boycott: true,
          reason: 'Exploits natural resources from occupied Palestinian territories',
          category: 'Cosmetics'
        }
      }),
      prisma.company.create({
        data: {
          name: 'Sabra',
          description: 'Food company producing hummus and Mediterranean foods',
          website: 'https://www.sabra.com',
          country: 'Israel/USA',
          boycott: true,
          reason: 'Co-owned by Israeli food company Strauss Group',
          category: 'Food & Beverage'
        }
      }),
      prisma.company.create({
        data: {
          name: 'Osem',
          description: 'Israeli food manufacturer',
          website: 'https://www.osem.co.il',
          country: 'Israel',
          boycott: true,
          reason: 'Major Israeli food company supporting Israeli economy',
          category: 'Food & Beverage'
        }
      }),
      prisma.company.create({
        data: {
          name: 'Ben & Jerry\'s',
          description: 'Ice cream company (alternative)',
          website: 'https://www.benjerry.com',
          country: 'USA',
          boycott: false,
          reason: 'Company stopped sales in occupied territories, supports Palestinian rights',
          category: 'Food & Beverage'
        }
      })
    ]);

    console.log(`✅ Created ${companies.length} companies`);

    // Create products
    const products = await Promise.all([
      prisma.product.create({
        data: {
          name: 'SodaStream Fizzi One Touch',
          barcode: '7290016660001',
          description: 'Automatic home soda maker with one-touch carbonation',
          category: 'Appliances',
          boycott: true,
          reason: 'Product of Israeli company SodaStream',
          alternatives: 'DrinkMate, Aarke, KitchenAid Sparkling Beverage Maker',
          companyId: companies[0].id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Ahava Mineral Hand Cream',
          barcode: '7290010300156',
          description: 'Moisturizing hand cream with Dead Sea minerals',
          category: 'Cosmetics',
          boycott: true,
          reason: 'Uses resources from occupied Palestinian territories',
          alternatives: 'L\'Occitane, The Body Shop, Kiehl\'s',
          companyId: companies[1].id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Sabra Classic Hummus',
          barcode: '040822011111',
          description: 'Classic hummus dip with tahini',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Co-owned by Israeli Strauss Group',
          alternatives: 'Tribe Hummus, Cedar\'s Hommus, Hope Hummus',
          companyId: companies[2].id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Bamba Peanut Snacks',
          barcode: '7290000040154',
          description: 'Puffcorn peanut butter flavored snacks',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Product of Israeli company Osem',
          alternatives: 'Planters, Cheez-It, Pirate\'s Booty',
          companyId: companies[3].id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Ben & Jerry\'s Chocolate Fudge Brownie',
          barcode: '076840000179',
          description: 'Ice cream with brownie chunks and fudge',
          category: 'Food & Beverage',
          boycott: false,
          reason: 'Company supports Palestinian rights and ended operations in occupied territories',
          alternatives: 'Already an ethical choice',
          companyId: companies[4].id
        }
      })
    ]);

    console.log(`✅ Created ${products.length} products`);
    console.log('🎉 Database seeded successfully!');
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
  } finally {
    await prisma.$disconnect();
  }
}

seed();
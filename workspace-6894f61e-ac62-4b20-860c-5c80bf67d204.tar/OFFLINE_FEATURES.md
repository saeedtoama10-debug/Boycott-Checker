# Offline Functionality

The Boycott Checker app now works offline with the following features:

## 🌐 **Offline Capabilities**

### **1. Service Worker Caching**
- Caches static assets and API responses
- Enables offline access to the app
- Automatic cache management

### **2. Local Storage Data**
- Stores companies and products data locally
- 24-hour cache duration
- Automatic cache refresh when online

### **3. Network Detection**
- Real-time online/offline status detection
- Visual indicators in the header
- Automatic fallback to cached data

### **4. Offline Search**
- Search functionality works offline using cached data
- Barcode scanning with manual input fallback
- Results indicate when using cached data

## 🎯 **How It Works**

### **When Online:**
1. App fetches fresh data from APIs
2. Updates local cache automatically
3. Shows "Online" status in header
4. Uses live data for searches

### **When Offline:**
1. App detects offline status
2. Shows "Offline" status in header
3. Uses cached data for searches
4. Displays "Cached" indicator
5. Shows offline notification banner

## 🔧 **Features**

### **Header Indicators:**
- 🟢 **Online** - Connected to internet
- 🔴 **Offline** - No internet connection
- 💾 **Cached** - Using cached data

### **Search Functionality:**
- Works both online and offline
- Shows cache status in results
- Automatic fallback to cached data

### **Barcode Scanner:**
- Camera scanning (when online)
- Manual input (always available)
- Offline barcode lookup using cache

### **Cache Management:**
- Automatic cache refresh (24-hour intervals)
- Manual refresh button when online
- Cache validation and cleanup

## 📱 **Testing Offline Mode**

### **To Test Offline:**
1. Use the app online to cache data
2. Disconnect from internet
3. Refresh the page
4. Try searching for products
5. Use barcode scanner with manual input

### **Test Searches:**
- "zara" - Should return cached results
- "pepsi" - Should return cached results
- "soda" - Should return cached results

### **Test Barcodes:**
- `8434620781234` - Zara T-Shirt
- `012000123456` - Pepsi Cola
- `7290016660001` - SodaStream

## 🛠 **Technical Implementation**

### **Service Worker (`/public/sw.js`)**
- Caches static assets
- Intercepts network requests
- Provides offline fallbacks

### **Offline Manager (`/src/lib/offline-manager.ts`)**
- Manages local storage
- Handles cache operations
- Provides offline search

### **React Hooks**
- `useOffline()` - Network status detection
- `useOfflineSearch()` - Offline-aware search

### **API Endpoints**
- `/api/companies` - All companies data
- `/api/products` - All products data
- `/api/search` - Search with offline fallback
- `/api/barcode` - Barcode lookup with offline fallback

## 📊 **Cache Details**

### **Cache Duration:** 24 hours
### **Storage:** localStorage
### **Data Size:** ~50KB (companies + products)
### **Cache Key:** `boycott-checker-data`

### **Cache Structure:**
```json
{
  "companies": [...],
  "products": [...],
  "lastUpdated": 1234567890
}
```

## 🔄 **Sync Behavior**

### **Automatic Sync:**
- On app launch (if cache is expired)
- When coming back online
- Every 24 hours

### **Manual Sync:**
- Click "Refresh Cache" button
- Only available when online
- Updates all cached data

## 🚨 **Limitations**

### **Offline Limitations:**
- No real-time data updates
- Barcode camera scanning may not work
- Limited to cached data only
- No new product additions

### **Browser Support:**
- Requires modern browser with localStorage
- Service Worker support required
- HTTPS required for production

## 🎯 **Best Practices**

1. **Keep Cache Updated:** Refresh cache regularly when online
2. **Test Offline:** Verify functionality before relying on it
3. **Storage Space:** Monitor localStorage usage
4. **Browser Compatibility:** Use supported browsers only
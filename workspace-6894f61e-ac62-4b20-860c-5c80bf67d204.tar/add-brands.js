const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function addNewBrands() {
  try {
    console.log('🌱 Adding Zara and Pepsi to database...');
    
    // Create Zara company
    const zara = await prisma.company.create({
      data: {
        name: 'Zara',
        description: 'Spanish fast fashion retailer owned by Inditex group',
        website: 'https://www.zara.com',
        country: 'Spain',
        boycott: true,
        reason: 'Zara has faced boycott calls for its perceived support of Israel and operating stores in Israeli settlements',
        category: 'Fashion & Apparel'
      }
    });

    console.log(`✅ Created Zara company`);

    // Create Pepsi company
    const pepsi = await prisma.company.create({
      data: {
        name: 'PepsiCo',
        description: 'American multinational food, snack, and beverage corporation',
        website: 'https://www.pepsico.com',
        country: 'USA',
        boycott: true,
        reason: 'PepsiCo has faced boycott calls for its business operations in Israel and support for Israeli policies',
        category: 'Food & Beverage'
      }
    });

    console.log(`✅ Created PepsiCo company`);

    // Create Zara products
    const zaraProducts = await Promise.all([
      prisma.product.create({
        data: {
          name: 'Zara Basic T-Shirt',
          barcode: '8434620781234',
          description: 'Classic cotton t-shirt from Zara basic collection',
          category: 'Fashion & Apparel',
          boycott: true,
          reason: 'Product of Zara, company facing boycott for Israel support',
          alternatives: 'H&M, Uniqlo, Everlane, Patagonia',
          companyId: zara.id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Zara High-Waist Jeans',
          barcode: '8434620785678',
          description: 'Slim fit high-waist denim jeans',
          category: 'Fashion & Apparel',
          boycott: true,
          reason: 'Product of Zara, company facing boycott for Israel support',
          alternatives: 'Levi\'s, Wrangler, Diesel, Calvin Klein',
          companyId: zara.id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Zara Leather Jacket',
          barcode: '8434620789012',
          description: 'Genuine leather moto-style jacket',
          category: 'Fashion & Apparel',
          boycott: true,
          reason: 'Product of Zara, company facing boycott for Israel support',
          alternatives: 'AllSaints, The Kooples, Mango, Urban Outfitters',
          companyId: zara.id
        }
      })
    ]);

    console.log(`✅ Created ${zaraProducts.length} Zara products`);

    // Create Pepsi products
    const pepsiProducts = await Promise.all([
      prisma.product.create({
        data: {
          name: 'Pepsi Cola 2L',
          barcode: '012000123456',
          description: 'Classic Pepsi cola soft drink, 2 liter bottle',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Product of PepsiCo, company facing boycott for Israel support',
          alternatives: 'Coca-Cola (alternative), Dr Pepper, local cola brands',
          companyId: pepsi.id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Lay\'s Classic Potato Chips',
          barcode: '028400058321',
          description: 'Classic salted potato chips by Lay\'s (PepsiCo brand)',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Product of PepsiCo, company facing boycott for Israel support',
          alternatives: 'Pringles, Kettle Brand, local chip brands',
          companyId: pepsi.id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Gatorade Fruit Punch',
          barcode: '052000123456',
          description: 'Sports drink with fruit punch flavor',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Product of PepsiCo, company facing boycott for Israel support',
          alternatives: 'Powerade, BodyArmor, coconut water, natural electrolyte drinks',
          companyId: pepsi.id
        }
      }),
      prisma.product.create({
        data: {
          name: 'Doritos Nacho Cheese',
          barcode: '028400041111',
          description: 'Classic nacho cheese flavored tortilla chips',
          category: 'Food & Beverage',
          boycott: true,
          reason: 'Product of PepsiCo, company facing boycott for Israel support',
          alternatives: 'Tostitos, private label tortilla chips, local brands',
          companyId: pepsi.id
        }
      })
    ]);

    console.log(`✅ Created ${pepsiProducts.length} PepsiCo products`);
    console.log('🎉 Successfully added Zara and PepsiCo to the database!');
    
  } catch (error) {
    console.error('❌ Error adding brands:', error);
  } finally {
    await prisma.$disconnect();
  }
}

addNewBrands();
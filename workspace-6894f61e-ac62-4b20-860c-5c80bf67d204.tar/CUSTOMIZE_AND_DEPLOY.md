# 🚀 Customize and Deploy Your Boycott Checker App

## 📋 Table of Contents
1. [Branding & Customization](#branding--customization)
2. [Data Management](#data-management)
3. [Technical Configuration](#technical-configuration)
4. [Deployment Options](#deployment-options)
5. [Legal & Compliance](#legal--compliance)
6. [Marketing & Launch](#marketing--launch)

---

## 🎨 Branding & Customization

### 1. Update App Identity

#### Basic Branding
```bash
# Update these files with your branding:
- src/app/page.tsx (app name, descriptions)
- src/app/layout.tsx (metadata, title)
- public/favicon.ico (your favicon)
- public/icon.png (PWA icon)
- public/apple-icon.png (iOS icon)
```

#### Colors & Theme
Edit `src/app/globals.css`:
```css
:root {
  --primary: YOUR_PRIMARY_COLOR;
  --primary-foreground: YOUR_PRIMARY_TEXT_COLOR;
  --secondary: YOUR_SECONDARY_COLOR;
  --secondary-foreground: YOUR_SECONDARY_TEXT_COLOR;
}
```

#### Update App Name
In `src/app/layout.tsx`:
```typescript
export const metadata: Metadata = {
  title: "Your App Name",
  description: "Your app description",
  // ... other metadata
}
```

### 2. Customize Content

#### Update Hero Section
In `src/app/page.tsx`, modify:
```typescript
<h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
  Your Main Headline
</h2>
<p className="text-muted-foreground max-w-2xl mx-auto text-sm sm:text-base">
  Your app description and value proposition
</p>
```

#### Update Badge/Tag
```typescript
<Badge variant="outline" className="text-xs sm:text-sm">
  Your Tag Line
</Badge>
```

---

## 📊 Data Management

### 1. Replace Sample Data

#### Update Companies
Edit `src/lib/offline-manager.ts`:
```typescript
const SAMPLE_COMPANIES = [
  {
    id: 1,
    name: "Your Company Name",
    country: "Country",
    boycott: true,
    reason: "Your reason for boycott",
    description: "Company description",
    website: "https://company-website.com",
    alternatives: "Alternative companies"
  },
  // Add your companies...
]
```

#### Update Products
```typescript
const SAMPLE_PRODUCTS = [
  {
    id: 1,
    name: "Product Name",
    companyId: 1,
    barcode: "1234567890123",
    boycott: true,
    reason: "Reason for boycott",
    description: "Product description"
  },
  // Add your products...
]
```

### 2. Database Schema

#### Update Prisma Schema
Edit `prisma/schema.prisma`:
```prisma
model Company {
  id          Int       @id @default(autoincrement())
  name        String
  country     String
  boycott     Boolean
  reason      String?
  description String?
  website     String?
  alternatives String?
  products    Product[]
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model Product {
  id          Int       @id @default(autoincrement())
  name        String
  barcode     String?   @unique
  boycott     Boolean
  reason      String?
  description String?
  companyId   Int
  company     Company   @relation(fields: [companyId], references: [id])
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}
```

---

## ⚙️ Technical Configuration

### 1. Environment Variables

Create `.env.local`:
```env
# App Configuration
NEXT_PUBLIC_APP_NAME="Your App Name"
NEXT_PUBLIC_APP_URL="https://your-domain.com"

# Database (if using external database)
DATABASE_URL="your-database-connection-string"

# Analytics (optional)
NEXT_PUBLIC_GA_ID="your-google-analytics-id"

# API Keys (if needed)
# API_KEY="your-api-key"
```

### 2. PWA Configuration

Update `public/manifest.json`:
```json
{
  "name": "Your App Name",
  "short_name": "AppName",
  "description": "Your app description",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#ffffff",
  "theme_color": "#your-primary-color",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}
```

### 3. SEO Optimization

Update `src/app/layout.tsx`:
```typescript
export const metadata: Metadata = {
  title: "Your App Name",
  description: "Your app description",
  keywords: ["your", "keywords", "here"],
  authors: [{ name: "Your Name" }],
  openGraph: {
    title: "Your App Name",
    description: "Your app description",
    url: "https://your-domain.com",
    siteName: "Your App Name",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Your App Name",
    description: "Your app description",
    images: ["/og-image.png"],
  },
}
```

---

## 🌐 Deployment Options

### 1. Vercel (Recommended)

#### Quick Deploy
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Deploy to production
vercel --prod
```

#### Custom Domain
1. Go to Vercel dashboard
2. Add your custom domain
3. Update DNS records

### 2. Netlify

#### Deploy
```bash
# Build the app
npm run build

# Deploy to Netlify
# Drag and drop the .next folder to Netlify
# Or use Netlify CLI
npm install -g netlify-cli
netlify deploy --prod --dir=.next
```

### 3. Self-Hosting

#### Docker Setup
Create `Dockerfile`:
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    restart: unless-stopped
```

Deploy:
```bash
docker-compose up -d
```

### 4. Traditional Hosting

#### Build for Production
```bash
npm run build
npm start
```

#### Use PM2 for Process Management
```bash
npm install -g pm2
pm2 start npm --name "your-app" -- start
pm2 startup
pm2 save
```

---

## ⚖️ Legal & Compliance

### 1. Privacy Policy

Create `public/privacy-policy.html`:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Privacy Policy - Your App Name</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h1>Privacy Policy</h1>
    <p>Last updated: [Date]</p>
    
    <h2>Data Collection</h2>
    <p>We collect [describe what data you collect]</p>
    
    <h2>Data Usage</h2>
    <p>We use data for [describe usage]</p>
    
    <h2>Data Storage</h2>
    <p>Data is stored [describe storage method]</p>
    
    <h2>User Rights</h2>
    <p>Users have the right to [describe rights]</p>
    
    <h2>Contact</h2>
    <p>Contact us at: your-email@example.com</p>
</body>
</html>
```

### 2. Terms of Service

Create `public/terms-of-service.html`:
```html
<!DOCTYPE html>
<html>
<head>
    <title>Terms of Service - Your App Name</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <h1>Terms of Service</h1>
    <p>Last updated: [Date]</p>
    
    <h2>Acceptance of Terms</h2>
    <p>By using this app, you agree to these terms...</p>
    
    <h2>Use of Service</h2>
    <p>You may use this service for [describe permitted use]</p>
    
    <h2>Limitations</h2>
    <p>[Describe limitations]</p>
    
    <h2>Disclaimer</h2>
    <p>[Include disclaimer]</p>
</body>
</html>
```

### 3. Add Legal Links

Update `src/app/page.tsx`:
```typescript
// Add to footer
<footer className="mt-16 py-8 border-t">
  <div className="container mx-auto px-4 text-center">
    <div className="flex justify-center gap-4 text-sm text-muted-foreground">
      <Link href="/privacy-policy">Privacy Policy</Link>
      <Link href="/terms-of-service">Terms of Service</Link>
      <Link href="/contact">Contact</Link>
    </div>
    <p className="mt-4 text-xs text-muted-foreground">
      © 2024 Your App Name. All rights reserved.
    </p>
  </div>
</footer>
```

---

## 📱 Marketing & Launch

### 1. App Store Optimization

#### Meta Tags
```typescript
// In layout.tsx
export const metadata: Metadata = {
  title: "Your App Name - Short Description",
  description: "Detailed description of your app's benefits",
  keywords: ["relevant", "keywords", "for", "your", "niche"],
}
```

#### Social Media Images
Create images:
- `public/og-image.png` (1200x630)
- `public/twitter-image.png` (1200x600)

### 2. Analytics Setup

#### Google Analytics
```typescript
// Add to layout.tsx
import { GoogleAnalytics } from '@next/third-parties/google'

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
        <GoogleAnalytics gaId="YOUR_GA_ID" />
      </body>
    </html>
  )
}
```

### 3. Launch Checklist

#### Pre-Launch
- [ ] Test all functionality
- [ ] Check responsive design
- [ ] Verify offline functionality
- [ ] Test barcode scanning
- [ ] Validate all links
- [ ] Check loading performance

#### Post-Launch
- [ ] Set up monitoring
- [ ] Configure analytics
- [ ] Test user feedback flow
- [ ] Monitor error logs
- [ ] Set up backup strategy

---

## 🔧 Advanced Customization

### 1. Add Authentication

```bash
npm install next-auth
```

Create `src/app/api/auth/[...nextauth]/route.ts`:
```typescript
import NextAuth from 'next-auth'
import GoogleProvider from 'next-auth/providers/google'

const handler = NextAuth({
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],
})

export { handler as GET, handler as POST }
```

### 2. Add User Accounts

#### Database Schema
```prisma
model User {
  id        String    @id @default(cuid())
  email     String    @unique
  name      String?
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
}
```

### 3. Add API Rate Limiting

```bash
npm install @upstash/ratelimit
```

Create `src/lib/rate-limit.ts`:
```typescript
import { Ratelimit } from '@upstash/ratelimit'
import { Redis } from '@upstash/redis'

export const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, '10 s'),
  analytics: true,
})
```

---

## 📈 Monetization Options

### 1. Ad Integration

```bash
npm install @googleadsense
```

### 2. Premium Features

#### Create Pro Version
```typescript
// Add premium features
const isPro = user?.subscription === 'pro'

if (isPro) {
  // Show premium features
}
```

### 3. Donation Support

Add donation button:
```typescript
<Button onClick={() => window.open('your-donation-link')}>
  Support This App
</Button>
```

---

## 🚀 Quick Start Deployment

### One-Click Vercel Deploy

```bash
# 1. Push to GitHub
git add .
git commit -m "Ready for deployment"
git push origin main

# 2. Connect to Vercel
# - Go to vercel.com
# - Import your GitHub repository
# - Deploy automatically

# 3. Configure domain
# - Add custom domain in Vercel dashboard
# - Update DNS records
```

### Environment Setup for Production

```bash
# On your server or deployment platform
NODE_ENV=production
NEXT_PUBLIC_APP_URL=https://your-domain.com
DATABASE_URL=your-production-database-url
```

---

## 📞 Support & Maintenance

### 1. Monitoring

```bash
# Add error tracking
npm install @sentry/nextjs
```

### 2. Backup Strategy

```bash
# Database backup script
#!/bin/bash
# Backup database daily
mysqldump -u user -p database > backup_$(date +%Y%m%d).sql
```

### 3. Update Process

```bash
# Update and redeploy
git pull origin main
npm install
npm run build
npm start
```

---

## 🎯 Success Metrics

### Key Performance Indicators
- Daily active users
- Search queries per day
- Barcode scans per day
- Offline usage percentage
- User retention rate
- App install count

### Improvement Areas
- Search accuracy
- Barcode recognition speed
- Offline performance
- User interface optimization
- Data freshness

---

This guide provides everything you need to customize, deploy, and maintain your boycott checker app. Follow these steps systematically to create a professional, scalable application that serves your community effectively.